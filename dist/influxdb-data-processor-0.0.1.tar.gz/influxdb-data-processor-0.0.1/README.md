# influxdb-data-processor
A data processor for data in influxDB
